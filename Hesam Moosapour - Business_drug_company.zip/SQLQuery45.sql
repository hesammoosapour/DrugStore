﻿select name as [دارو خانه های فعال]
from drug_stores where inactiveity_comment is null


--لیست داروخانه های فعال
