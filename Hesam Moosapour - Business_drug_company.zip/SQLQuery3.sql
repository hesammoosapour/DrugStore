USE [BusinessCompany]
GO

INSERT INTO [dbo].[users]
           ([user_name]
           ,[password]
           ,[permission_id])
     VALUES
           ('moosapour'
           ,'3456'
           ,2)
GO


