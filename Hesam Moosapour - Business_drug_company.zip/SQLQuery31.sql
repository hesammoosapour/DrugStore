update products
set exp_date ='2022-02-20'
where id=8